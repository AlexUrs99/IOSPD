#define IDR_SIEMENU1		101
#define IDI_SIEICON1		201

#define IDD_ABOUT			300

#define IDC_STATIC			1010
#define IDC_STATIC1			1011
#define IDC_DISPLAY			1014

#define ID_FILE_OPEN		40000
#define ID_FILE_CLOSE		40001
#define ID_FILE_EXIT		40002
#define ID_HELP_ABOUT		40003
#define ID_OPER_OP0			40010
#define ID_OPER_OP1			40011
#define ID_OPER_OP2			40012
#define ID_OPER_OP3			40013
